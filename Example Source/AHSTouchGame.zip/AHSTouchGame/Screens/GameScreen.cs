﻿using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;

namespace $safeprojectname$.Screens
{
    class GameScreen : GameLibrary.Screen
    {
        #region Variables

        private ContentManager Content;

        private SpriteBatch SpriteBatch;

        private Texture2D bg;
        private Rectangle fullscreen;

        private SpriteFont gameFont;

        private MouseState state;

        private float timeInGame;

        private int score;
        private int repetitions;

        private Vector2 scorePosition;

        #endregion Variables

        public override void Initialize()
        {
            timeInGame = 0.0f;

            //Setup Values
            repetitions = ((Manager)ScreenManager).Repetitions;

            //Tracked during the game
            score = 0;

            fullscreen = new Rectangle(0, 0, ScreenManager.GraphicsDevice.Viewport.Width, ScreenManager.GraphicsDevice.Viewport.Height);

            ScreenManager.Game.IsMouseVisible = false;

            base.Initialize();
        }

        public override void LoadContent()
        {
            Content = new ContentManager(ScreenManager.Game.Services, "Content");

            SpriteBatch = ScreenManager.SpriteBatch;

            bg = Content.Load<Texture2D>("Sprites/background");

            gameFont = Content.Load<SpriteFont>("Font");

            float scoreLength = (gameFont.MeasureString("999/999")).X;
            scorePosition = new Vector2(this.ScreenManager.ScaleXPosition((this.ScreenManager.GraphicsDevice.PresentationParameters.BackBufferWidth / 2.0f) - (scoreLength / 2.0f)), this.ScreenManager.ScaleYPosition(20.0f));
        }

        public override void UnloadContent()
        {
            Content.Unload();
        }

        public override void Update(Microsoft.Xna.Framework.GameTime gameTime)
        {
            timeInGame += (float)gameTime.ElapsedGameTime.TotalMilliseconds;

            base.Update(gameTime);
        }

        public override void HandleInput(Microsoft.Xna.Framework.GameTime gameTime, GameLibrary.InputManager input)
        {
            state = input.MouseState;

            base.HandleInput(gameTime, input);
        }

        /// <summary>
        /// Updates the score. If the score == repetitions, sets the win game
        /// to true.
        /// </summary>
        private void UpdateScore()
        {
            score++;

            if (score == repetitions)
            {
                ((Manager)this.ScreenManager).Time = timeInGame;
                ((Manager)this.ScreenManager).Missed = ;

                EndScreen es = new EndScreen();

                this.ScreenManager.AddScreen(es, false);

                this.ScreenManager.RemoveScreen(this);
            }
        }

        public override void Draw(Microsoft.Xna.Framework.GameTime gameTime, Microsoft.Xna.Framework.Matrix transform)
        {
            SpriteBatch.Begin(SpriteSortMode.FrontToBack, null, null, null, null, null, transform);
            
            SpriteBatch.Draw(bg, fullscreen, Color.White);

            SpriteBatch.DrawString(gameFont, score.ToString() + "/" + repetitions.ToString(), scorePosition, Color.White);

            SpriteBatch.End();
        }
    }
}